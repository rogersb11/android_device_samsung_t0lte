#!/sbin/busybox sh

# Ketut P. Kumajaya, Apr 2014

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

# Recursive delete /data exclude /data/media
if /sbin/busybox [ -d /data/media/.secondrom/data ]; then
  cd /data/media/.secondrom/data
  for f in $(ls -a | grep -v ^media$); do
    rm -rf $f
  done
  cd /
fi
