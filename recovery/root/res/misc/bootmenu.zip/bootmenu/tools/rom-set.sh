#!/sbin/sh

# Ketut P. Kumajaya, May 2013

/sbin/echo -n $1 > /.secondrom/media/.defaultrecovery
