#!/sbin/sh

# Ketut P. Kumajaya, May 2013

SECONDROM=1
[ -f /.secondrom/media/.secondrom/system.img ] || SECONDROM=0

exit $SECONDROM
